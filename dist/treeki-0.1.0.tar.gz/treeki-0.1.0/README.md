# Treeki
Simle class for display console tree model of object.
For example class with class as atributes
